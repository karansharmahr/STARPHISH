<?php
header('Location: <CUSTOM>');
exit();

